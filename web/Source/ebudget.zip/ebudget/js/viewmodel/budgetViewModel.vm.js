/**
*	Fonction de création de la date du jour pour ajouter à la création d'un budget ou d'une opération
*/
function date_heure()
{
    date = new Date;
    annee = date.getFullYear();
    moi = date.getMonth();
    mois = new Array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
    j = date.getDate();
    jour = date.getDay();
    jours = new Array('Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi');

   
    resultat = j+'/'+mois[moi]+'/'+annee;
    return resultat;
}

/**
*	ViewModel de l'application
*/

function budgetViewModel(){
	var self = this;
	var total = 0;
	/* Liste des budget **/
	self.budgets = ko.observableArray();
	self.chooseBudget = ko.observable();
	self.chooseBudget(null);

	/* Champs d'ajout d'un budget ou d'une opération **/
	self.newBudgetNom = ko.observable("");
	self.newBudgetValeur = ko.observable("");
	self.newOperationNom = ko.observable("");
	self.newOperationValeur = ko.observable("");

	/* Récupération du budget à partir d'un fichier JSON **/
	$.getJSON('./budget.json', function(values) {		
		$.each(values.budget, function(i, h){
			operations = ko.observableArray();
			$.each(h.operations, function(i, o){
				operations.push(new operation(o.nom, o.valeur, o.dateOperation));
			});
			budg = new budget(h.name, h.valeur, h.payer, operations);
			self.budgets.push(budg);
		});
	});

	/* Calcul + affichage du total du budget **/
	self.totalBudget = ko.computed(function(){
		var total = 0;
		ko.utils.arrayForEach(self.budgets(), function(b){
			total = total + parseInt(b.valeur());
		});
		return total;
	});

	/* Calcul + affichage du ratio entre le budget total et le budget payé **/
	self.restantBudget = ko.computed(function(){
		var total = 0;
		ko.utils.arrayForEach(self.budgets(), function(b){
			if(b.payer() == "0")
				total = total + parseInt(b.resteBudget());
		});
		return total;
	});

	/* Pourcentage d'accomplissement du budget **/
	self.percentBudgetAccompli = ko.computed(function(){
		return 100 - (self.restantBudget() * 100) / self.totalBudget(); 
	});


	/** FUNCTION  **/
	/* Sauvegarde Tous les Budgets dans le fichier JSON **/
	self.saveBudget = function(){	
        var data = ko.toJSON(self.budgets);
		$.ajax({
            url: "php/ajax.php",
            type: "POST",
            data: data,
            datatype: "json",
            processData: false,
            contentType: "application/json; charset=utf-8",
            success: function (result) {

            }
        });
        return true;
	}

	/* Ajoute un budget à la liste + Sauvegarde dans le fichier JSON **/
	self.addBudget = function(){
		operations = ko.observableArray();
		self.budgets.push(new budget(self.newBudgetNom(), self.newBudgetValeur(), "0", operations));
		self.saveBudget();
		self.newBudgetNom("");
		self.newBudgetValeur("");
		return true;
	}

	/* Sélectionne un Budget **/
	self.showBudget = function(budget){
		self.chooseBudget(budget);		
		return true;
	}

	/* Supprime le budget choisi + Sauvegarde dans le fichier JSON **/
	self.deleteBudget = function(){		
		self.budgets.remove(self.chooseBudget());
		self.saveBudget();
		return true;
	}

	/* 	Place le budget au statut Payer + Ajout de l'opération "Paiement automatique" d'un montant du restant à payer du budget
	 	+ Sauvegarde dans le fichier JSON 
 	**/
	self.editPayer = function(){
		self.chooseBudget().payer("1");		
		self.chooseBudget().operations.push(new operation("Paiement automatique",self.chooseBudget().resteBudget(), date_heure()));
		self.saveBudget();
		return true;
	}

	/* Réinitialise tous les budget+opération + Sauvegarde dans le fichier JSON **/
	self.reinitialiser = function(){
		ko.utils.arrayForEach(self.budgets(), function(b){
			b.payer("0");
			b.operations.removeAll();
		});
		self.saveBudget();
	}

	/* Supprime une opération + Sauvegarde dans le fichier JSON **/
	self.deleteOperation = function(){
		self.chooseBudget().operations.removeAll();
		self.chooseBudget().verificationPayer();
		self.saveBudget();
	}

	/* Ajoute une opération + Sauvegarde dans le fichier JSON **/
	self.addOperation = function(){
		if(self.newOperationValeur() > self.chooseBudget().resteBudget()){
			alert("Montant suppérieur au restant du budget !");
			return false;
		}
		else{
			self.chooseBudget().operations.push(new operation(self.newOperationNom(), self.newOperationValeur(), date_heure()));	

			self.newOperationNom("");
			self.newOperationValeur("");
			
			self.chooseBudget().verificationPayer();
			self.saveBudget();
			return true;
		}		
	}		
}
function operation(nom, valeur, dateOperation)
{
	var self = this;

	self.nom = ko.observable(nom);
	self.valeur = ko.observable(valeur);
	self.dateOperation = ko.observable(dateOperation);
}
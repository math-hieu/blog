function budget(name, valeur, payer, operations){
	var self = this;

	self.name = ko.observable(name);
	self.valeur = ko.observable(valeur);
	self.payer = ko.observable(payer);

	/** Concaténation de la valeur du budget avec le sigle € */ 
	self.fullValeur = ko.computed(function() {
		return self.valeur() + "€";
	}, self);

	self.operations = operations;

	/** Somme de toutes les opérations pour le budget en cours **/
	self.sommeOperation = function(){
		var total = 0;
		ko.utils.arrayForEach(self.operations(), function(o){			
			total = total + parseInt(o.valeur());
		});
		return total;
	}

	/** Vérifie si le paiement doit être au statut "Payer" **/
	self.verificationPayer = function(){
		if(self.sommeOperation() == self.valeur()){
			self.payer("1");
		}
		else{
			self.payer("0");
		}
	}

	/** Restant à Payer pour un budget **/
	self.resteBudget = function(){
		return parseInt(self.valeur()) - self.sommeOperation();
	}

	/** Pourcentage de paiement pour le budget en cours / Utilisé pour changer de couleur le budget **/ 
	self.calculPercent = function(){
		var paye = self.sommeOperation();
		var valeur = parseInt(self.valeur());
		return ( paye * 100) / valeur;
	}
}
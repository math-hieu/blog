	/**
	*	Custom Binding de la progressBar dans la vue d'index
	*/

	ko.bindingHandlers.progressbar = {
		init: function(element, valueAccessor, allBindings, bindingContext) {
			$(element).css({width: bindingContext.percentBudgetAccompli()+"%"});
	    },
	    update: function(element, valueAccessor, allBindings, bindingContext) {
			$(element).css({width: bindingContext.percentBudgetAccompli()+"%"});
	    }
	};

	/**
	*	Custom Binding pour avoir des couleur différentes suivant l'avancement d'un budget
	*/
	ko.bindingHandlers.colorBudget = {
		init: function(element, valueAccessor, allBindings, bindingContext) {
			if(bindingContext.calculPercent() == 0){
				$(element).css({"background-color": "#F4F4F4", "color": "#333"});
			}
			else if(bindingContext.calculPercent() > 0 && bindingContext.calculPercent() <= 50){
				$(element).css({"background-color": "#D7B050", "color": "#fff"});
			}
			else if(bindingContext.calculPercent() > 50 && bindingContext.calculPercent() < 100){
				$(element).css({"background-color": "#4EADD7", "color": "#fff"});
			}
			else if(bindingContext.calculPercent() == 100){
				$(element).css({"background-color": "#62C697", "color": "#fff"});
			}			
	    },
	    update: function(element, valueAccessor, allBindings, bindingContext) {
			if(bindingContext.calculPercent() == 0){
				$(element).css({"background-color": "#F4F4F4", "color": "#333"});
			}
			else if(bindingContext.calculPercent() > 0 && bindingContext.calculPercent() <= 50){
				$(element).css({"background-color": "#D7B050", "color": "#fff"});
			}
			else if(bindingContext.calculPercent() > 50 && bindingContext.calculPercent() < 100){
				$(element).css({"background-color": "#4EADD7", "color": "#fff"});
			}
			else if(bindingContext.calculPercent() == 100){
				$(element).css({"background-color": "#62C697", "color": "#fff"});
			}
	    }
	};
	
	/**
	*	Instanciation de pager et application du binding de Knockout
	*/
	pager.Href.hash = '#!/';
    var vm = new budgetViewModel();
    pager.extendWithPage(vm);
    ko.applyBindings(vm);
    pager.start("home");
    



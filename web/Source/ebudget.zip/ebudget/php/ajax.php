<?php
	$array = array();
	$data = json_decode($HTTP_RAW_POST_DATA);
	$array['budget'] = $data;
	file_put_contents("../budget.json",json_encode($array));
?>

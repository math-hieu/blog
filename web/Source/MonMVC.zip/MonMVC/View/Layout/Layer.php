<html>
    <head>     
    </head>
    <body>
    	<header>
        
	    </header>
	    <div class="content">
	        <?php include("../View/".$view.".php"); ?>
	    </div>
	    <footer>
	        
	    </footer>
    </body>    
</html>
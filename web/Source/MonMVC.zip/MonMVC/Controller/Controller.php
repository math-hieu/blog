<?php

class Controller {
    /**
    *    Execute l'action récupéré dans App
    */
    public function  Execute($action) {
        // On vérifie si la méthode existe (cette fonction vérifie dans la classe fille qui héritera de cette classe)
        if (method_exists($this, 'exec'.$action)){
            // On execute l'action
            $this->{'exec'.$action}();
        }
        else{
            $this->fpagenotfound();
        }
    }

    public function fpagenotfound(){        
        include("../View/PageNotFound.html");
    }
}

?>
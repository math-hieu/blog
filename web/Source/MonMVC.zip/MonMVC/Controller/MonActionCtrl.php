<?php

class MonActionCtrl extends Controller {
    public function execindex(){
        // Nom de la vue qui sera Include dans le layout
        $view = "indexView";
        $name = "Mthomas";
        // On inclue le layout
        include '../View/Layout/Layer.php';
    }
}

?>
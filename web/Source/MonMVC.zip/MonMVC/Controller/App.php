<?php
class App {

    /**
     * Fonction principale
     */
    public function Run()
    {
            //Le programme commence par charger le controleur et l'action par défaut.
            $control = new MonActionCtrl();
            $action = "index";

            //recherche du controleur et de l'action approprié du type : index.php?control=MonController&page=MaPage
            if (isset($_GET["control"]))
            {
                // On vérifie si le controleur demandé existe
                if (file_exists('./'.$_GET["control"].'Ctrl.php'))
                {
                    // on instancie notre Controleur   
                    $name_control = $_GET["control"]."Ctrl";
                    $control = new $name_control ();
                }
            }
            // On récupère la page/action demandé
            if (isset($_GET["page"]))
            {
                $action = $_GET["page"];
            }

            //execution du controler
            $control->Execute($action);
    }
}
?>
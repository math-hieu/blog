<?php
    include('../Controller/App.php');
    include('../Controller/Controller.php');
    include('../Controller/MonActionCtrl.php');
 
    // On instancie la classe App
    $app = new App();
    // On execute la fonction que nous venons de développer
    $app->Run();
?>